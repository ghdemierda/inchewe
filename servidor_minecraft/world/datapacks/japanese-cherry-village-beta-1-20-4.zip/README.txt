   _____            __ _                _____            _           
  / ____|          / _| |              |  __ \          | |          
 | |     _ __ __ _| |_| |_ ___ _ __ ___| |__) |___  __ _| |_ __ ___  
 | |    | '__/ _` |  _| __/ _ \ '__/ __|  _  // _ \/ _` | | '_ ` _ \ 
 | |____| | | (_| | | | ||  __/ |  \__ \ | \ \  __/ (_| | | | | | | |
  \_____|_|  \__,_|_|  \__\___|_|  |___/_|  \_\___|\__,_|_|_| |_| |_|

########
# INFO #
########

Thank you for downloading this datapack for Minecraft Java 1.20.4.

This product is a BETA release of the full version, playable at:
craftersrealm.net:25596

Please be aware that this datapack is experimental and may potentially corrupt your world!

Updates about this or new builds can be followed at: https://discord.gg/97vnVeY8ST

This build is the intellectual property of Source_404 and is part of the CraftersRealm project. It is prohibited to share or claim ownership of this build.

All rights reserved.

##############################
# How to Install a Datapack: #
##############################

1) Unzip the downloaded file.

2) Ensure you have fully read the README file and are aware of the intellectual property rights and the potential risks of installing a datapack.

3) Place the unzipped folder into the datapacks folder of your world.

4) In-game, click on the "Play Selected World" button.

5) When prompted with "World using Experimental settings is not supported," click on "I know what I'm doing!"

6) Find the structure by exploring the world or via the command /locate structure japanese:cherry_village.